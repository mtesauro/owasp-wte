#!/bin/bash

# -- jojo --
# description: echo text on the command line
# param: text - text to echo
# -- jojo --

echo "echo'd text: $TEXT"
echo "jojo_return_value name=bob"
echo "jojo_return_value age=99"
exit 0
