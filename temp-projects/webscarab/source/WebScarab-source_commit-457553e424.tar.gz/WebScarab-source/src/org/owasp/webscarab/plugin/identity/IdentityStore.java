package org.owasp.webscarab.plugin.identity;

public interface IdentityStore {

}
