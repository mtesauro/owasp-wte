package org.owasp.webscarab.plugin.identity;

import java.io.File;

import org.owasp.webscarab.model.StoreException;

public class FileSystemStore implements IdentityStore {

	public FileSystemStore(File dir, String session) throws StoreException {
		
	}
}
