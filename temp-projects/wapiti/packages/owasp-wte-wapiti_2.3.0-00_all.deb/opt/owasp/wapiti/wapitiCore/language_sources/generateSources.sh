xgettext --copyright-holder="2009-2013 Nicolas SURRIBAS" --package-name="Wapiti" --package-version="SVN" --from-code=UTF-8 -L Python --no-wrap -d wapiti -o de.po -f file_list.txt -j
xgettext --copyright-holder="2009-2013 Nicolas SURRIBAS" --package-name="Wapiti" --package-version="SVN" --from-code=UTF-8 -L Python --no-wrap -d wapiti -o en.po -f file_list.txt -j
xgettext --copyright-holder="2009-2013 Nicolas SURRIBAS" --package-name="Wapiti" --package-version="SVN" --from-code=UTF-8 -L Python --no-wrap -d wapiti -o es.po -f file_list.txt -j
xgettext --copyright-holder="2009-2013 Nicolas SURRIBAS" --package-name="Wapiti" --package-version="SVN" --from-code=UTF-8 -L Python --no-wrap -d wapiti -o fr.po -f file_list.txt -j
xgettext --copyright-holder="2009-2013 Nicolas SURRIBAS" --package-name="Wapiti" --package-version="SVN" --from-code=UTF-8 -L Python --no-wrap -d wapiti -o ms.po -f file_list.txt -j
