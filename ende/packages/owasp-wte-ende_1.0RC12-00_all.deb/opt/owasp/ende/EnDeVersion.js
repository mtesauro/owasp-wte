EnDe.VERDATE  = '09-jun-12';
EnDe.VERSION  = '1.0rc11';
